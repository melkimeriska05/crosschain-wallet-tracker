import React from 'react';
import WalletForm from './components/WalletForm';

function App() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">CrossChain Wallet Tracker</h1>
      <WalletForm />
    </div>
  );
}

export default App;
