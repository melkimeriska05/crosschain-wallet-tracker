import React, { useState } from 'react';

function WalletForm() {
  const [ethAddress, setEthAddress] = useState('');
  const [btcAddress, setBtcAddress] = useState('');
  const [balance, setBalance] = useState(null);

  const fetchBalance = async () => {
    const eth = await fetch(`https://api.etherscan.io/api?module=account&action=balance&address=${ethAddress}&tag=latest&apikey=YourApiKeyToken`)
      .then(res => res.json());
    const btc = await fetch(`https://blockchain.info/q/addressbalance/${btcAddress}?confirmations=6`)
      .then(res => res.text());

    setBalance({
      eth: eth.result,
      btc: btc
    });
  };

  return (
    <div className="space-y-4">
      <input type="text" placeholder="Ethereum Address" value={ethAddress} onChange={e => setEthAddress(e.target.value)} className="border p-2 w-full" />
      <input type="text" placeholder="Bitcoin Address" value={btcAddress} onChange={e => setBtcAddress(e.target.value)} className="border p-2 w-full" />
      <button onClick={fetchBalance} className="bg-blue-500 text-white px-4 py-2 rounded">Check Balance</button>
      {balance && (
        <div className="mt-4">
          <p>ETH Balance: {balance.eth}</p>
          <p>BTC Balance: {balance.btc}</p>
        </div>
      )}
    </div>
  );
}

export default WalletForm;
