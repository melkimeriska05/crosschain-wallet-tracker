# CrossChain Wallet Tracker

A simple React-based prototype that allows users to input Ethereum and Bitcoin wallet addresses and view balances using public APIs.

## Features
- Input wallet address (ETH & BTC)
- Fetch balance from public APIs (Etherscan, Blockchain.info)
- Display balances in a clean UI

## Technologies
- React
- Tailwind CSS

## Setup
```bash
npm install
npm run dev
```

---
